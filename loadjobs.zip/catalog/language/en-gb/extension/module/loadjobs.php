<?php
// Heading
$_['heading_title'] = 'Jobs List';
